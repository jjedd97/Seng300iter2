# SENG300
Authors: Jocelyn Donnelly, Rishabh Kumaria, Nathan Ou


Command line arguments should be in the form <directory path> <type>.
